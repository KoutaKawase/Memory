function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Card_1 = require("./Card");

      var Board =
      /** @class */
      function () {
        function Board(group) {
          this._group = group;
        }

        Object.defineProperty(Board.prototype, "group", {
          get: function get() {
            return this._group;
          },
          enumerable: true,
          configurable: true
        });
        Board.rowLength = Card_1.Card.width * 10;
        Board.colLength = Card_1.Card.height * 3;
        Board.posY = 49;
        return Board;
      }();

      exports.Board = Board;
    }, {
      "./Card": 2
    }],
    2: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Card =
      /** @class */
      function () {
        function Card(back, surface, id) {
          this._back = back;
          this._surface = surface; //カードのバリューを判断するために使うid m1なら1 m2なら2

          this._id = id;
        }

        Object.defineProperty(Card.prototype, "id", {
          get: function get() {
            return this._id;
          },
          enumerable: true,
          configurable: true
        });

        Card.prototype.setPosition = function (x, y) {
          this._back.x = x;
          this._back.y = y;
          this._surface.x = x;
          this._surface.y = y;
        };

        Card.prototype.handleClick = function (scene, referee, list, score, board, time) {
          var _this = this;

          referee.incrementCount();
          referee.keepChoicedCard(this);

          if (referee.clickCount === 2) {
            for (var _i = 0, list_1 = list; _i < list_1.length; _i++) {
              var card = list_1[_i];
              card.back.touchable = false;
              card.back.modified();
            }
          } //正解した時


          if (referee.clickCount === 2 && referee.checkSameCard()) {
            score.addPoint(referee.continuousCurrentCount);
            list.forEach(function (card) {
              if (card.id === _this._id) {
                card.back.destroy();
                card.back.modified();
                card.surface.destroy();
                card.surface.modified();
              }
            });

            if (referee.isAllDone(board)) {
              g.game.vars.gameState.allDone = true; //全て完了した時点での残り時間

              g.game.vars.gameState.restTime = Math.ceil(time.now);
            }

            referee.continuousCurrentCount += 1;
          }

          if (referee.clickCount === 2 && !referee.checkSameCard()) {
            referee.continuousCurrentCount = 0;
          }

          this.back.opacity = 0; //一度クリックした画像はもう押せないようにする

          this.back.touchable = false;
          this.back.modified(); //二回目の時だけ元に戻す処理をする

          if (referee.clickCount === 2) {
            scene.setTimeout(function () {
              _this.back.opacity = 0;

              _this.back.modified(); //１つめに選んだモノを元に戻す


              referee.choicedCard[0].back.opacity = 0;

              for (var _i = 0, list_2 = list; _i < list_2.length; _i++) {
                var card = list_2[_i];
                card.back.touchable = true;
                card.back.modified();
              }

              referee.resetChoicedCards();
              referee.resetCount();
            }, 500);
          }
        };

        Object.defineProperty(Card.prototype, "back", {
          get: function get() {
            return this._back;
          },
          enumerable: true,
          configurable: true
        });
        Object.defineProperty(Card.prototype, "surface", {
          get: function get() {
            return this._surface;
          },
          enumerable: true,
          configurable: true
        });
        Card.width = 63;
        Card.height = 101;
        return Card;
      }();

      exports.Card = Card;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Card_1 = require("./Card");

      var SpriteFactory_1 = require("./utils/SpriteFactory");

      var Board_1 = require("./Board");

      var Deck =
      /** @class */
      function () {
        function Deck() {
          this._cardList = [];
        } //単純にシャッフルせずデッキ内のカードを作成


        Deck.prototype.init = function (scene) {
          this._cardList = this.createFullDeck(scene);
        };

        Deck.prototype.shuffle = function () {
          var _a; //cardListを複製


          var list = this._cardList.concat();

          for (var i = list.length - 1; i > 0; i--) {
            var j = Math.floor(g.game.random.generate() * (i + 1));
            _a = [list[j], list[i]], list[i] = _a[0], list[j] = _a[1];
          }

          this._cardList = list.concat();
        };

        Deck.prototype.calclateCardsPosition = function () {
          // this._cardList.forEach((card, index) => {
          //   if (0 < index && index < 9) {
          //   }
          //   card.setPosition(x, y);
          // });
          var index = 0;

          for (var y = 0; y < Board_1.Board.colLength; y += Card_1.Card.height) {
            for (var x = 0; x < Board_1.Board.rowLength; x += Card_1.Card.width, index++) {
              this._cardList[index].setPosition(x, y);
            }
          }
        };

        Deck.prototype.createFullDeck = function (scene) {
          var cardList = []; //同じカードを二枚持った30枚構成にするために二回する

          for (var count = 0; count < 2; count++) {
            for (var i = 0; i < 15; i++) {
              var back = SpriteFactory_1.createSprite(scene, "cardBack");
              var surfaceAssetID = "m" + (i + 1);
              var id = i + 1;
              var surface = SpriteFactory_1.createSprite(scene, surfaceAssetID); //30枚にする必要があるので二回する

              cardList.push(new Card_1.Card(back, surface, id));
            }
          }

          return cardList;
        };

        Object.defineProperty(Deck.prototype, "cardList", {
          get: function get() {
            return this._cardList;
          },
          enumerable: true,
          configurable: true
        });
        return Deck;
      }();

      exports.Deck = Deck;
    }, {
      "./Board": 1,
      "./Card": 2,
      "./utils/SpriteFactory": 9
    }],
    4: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      }); // ゲームの様々な判定を行うクラス

      var Referee =
      /** @class */
      function () {
        function Referee() {
          this._clickCount = 0;
          this._choicedCard = []; //連続性回数をカウントする

          this._continuousCurrentCount = 0;
        }

        Referee.prototype.incrementCount = function () {
          this._clickCount++;
        };

        Object.defineProperty(Referee.prototype, "clickCount", {
          get: function get() {
            return this._clickCount;
          },
          enumerable: true,
          configurable: true
        });
        Object.defineProperty(Referee.prototype, "continuousCurrentCount", {
          get: function get() {
            return this._continuousCurrentCount;
          },
          set: function set(count) {
            this._continuousCurrentCount = count;
          },
          enumerable: true,
          configurable: true
        });
        Object.defineProperty(Referee.prototype, "choicedCard", {
          get: function get() {
            return this._choicedCard;
          },
          enumerable: true,
          configurable: true
        });

        Referee.prototype.keepChoicedCard = function (card) {
          if (this._choicedCard.length < 2) {
            this._choicedCard.push(card);
          }
        };

        Referee.prototype.resetCount = function () {
          this._clickCount = 0;
        };

        Referee.prototype.resetChoicedCards = function () {
          if (this._choicedCard.length === 2) {
            this._choicedCard = [];
          }
        };

        Referee.prototype.isAllDone = function (board) {
          return board.group.children.length === 0;
        };

        Referee.prototype.checkSameCard = function () {
          var choiced = this._choicedCard;

          if (choiced.length === 2 && choiced[0].id === choiced[1].id) {
            return true;
          }

          return false;
        };

        return Referee;
      }();

      exports.Referee = Referee;
    }, {}],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Score =
      /** @class */
      function () {
        function Score(score) {
          this._score = score;
        }

        Object.defineProperty(Score.prototype, "score", {
          get: function get() {
            return this._score;
          },
          enumerable: true,
          configurable: true
        });

        Score.prototype.addPoint = function (currentCount) {
          if (currentCount > 0) {
            //連続正解１回なら1.1倍 二回なら1.2倍にする
            this._score += Score.defaultPoint * (1 + currentCount / 10);
            return;
          }

          this._score += Score.defaultPoint;
        };

        Score.prototype.calcFinalScore = function () {
          //制限時間内に全て終わっていたら残り秒*100を加算する
          if (g.game.vars.gameState.allDone) {
            var rest = g.game.vars.gameState.restTime;
            return this._score + rest * 100;
          }

          return this._score;
        };

        Object.defineProperty(Score.prototype, "label", {
          get: function get() {
            return this._label;
          },
          set: function set(label) {
            this._label = label;
          },
          enumerable: true,
          configurable: true
        });

        Score.prototype.createLabel = function (font, scene) {
          return new g.Label({
            scene: scene,
            text: 0 + "Pt",
            fontSize: 20,
            font: font,
            x: Score.labelX,
            y: Score.labelY
          });
        };

        Score.labelX = 20;
        Score.labelY = 15; //正解したときの入るポイント

        Score.defaultPoint = 2000;
        return Score;
      }();

      exports.Score = Score;
    }, {}],
    6: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Time =
      /** @class */
      function () {
        function Time(limit) {
          this._limit = limit;
          this._now = this._limit;
        }

        Object.defineProperty(Time.prototype, "label", {
          get: function get() {
            return this._label;
          },
          set: function set(label) {
            this._label = label;
          },
          enumerable: true,
          configurable: true
        });
        Object.defineProperty(Time.prototype, "limit", {
          set: function set(limit) {
            this._limit = limit;
          },
          enumerable: true,
          configurable: true
        });
        Object.defineProperty(Time.prototype, "now", {
          get: function get() {
            return this._now;
          },
          set: function set(time) {
            this._now = time;
          },
          enumerable: true,
          configurable: true
        });

        Time.prototype.createLabel = function (font, scene) {
          return new g.Label({
            scene: scene,
            text: "TIME " + this._limit,
            fontSize: 20,
            font: font,
            x: Time.labelX,
            y: Time.labelY
          });
        };

        Time.labelX = g.game.width - 200;
        Time.labelY = 15;
        return Time;
      }();

      exports.Time = Time;
    }, {}],
    7: [function (require, module, exports) {
      "use strict";

      var main_1 = require("./main");

      module.exports = function (originalParam) {
        var param = {};
        Object.keys(originalParam).forEach(function (key) {
          param[key] = originalParam[key];
        }); // セッションパラメーター

        param.sessionParameter = {}; // コンテンツが動作している環境がRPGアツマール上かどうか

        param.isAtsumaru = typeof window !== "undefined" && typeof window.RPGAtsumaru !== "undefined"; // 乱数生成器

        param.random = g.game.random;
        var limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数

        var scene = new g.Scene({
          game: g.game
        }); // セッションパラメーターを受け取ってゲームを開始します

        scene.message.add(function (msg) {
          if (msg.data && msg.data.type === "start" && msg.data.parameters) {
            param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加

            if (msg.data.parameters.randomSeed != null) {
              param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
            }

            g.game.popScene();
            main_1.main(param);
          }
        });
        scene.loaded.add(function () {
          var currentTickCount = 0;
          scene.update.add(function () {
            currentTickCount++; // 待ち時間を超えた場合はゲームを開始します

            if (currentTickCount > limitTickToWait) {
              g.game.popScene();
              main_1.main(param);
            }
          });
        });
        g.game.pushScene(scene);
      };
    }, {
      "./main": 8
    }],
    8: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Deck_1 = require("./Deck");

      var Board_1 = require("./Board");

      var Referee_1 = require("./Referee");

      var Score_1 = require("./Score");

      var Time_1 = require("./Time");

      function main(param) {
        var scene = new g.Scene({
          game: g.game,
          assetIds: ["m1", "m2", "m3", "m4", "m5", "m6", "m7", "m8", "m9", "m10", "m11", "m12", "m13", "m14", "m15", "cardBack", "bmpPng", "glyph"]
        });
        g.game.vars.gameState = {
          score: 0
        };
        var score = new Score_1.Score(g.game.vars.gameState.score);
        var time = new Time_1.Time(55);

        if (param.sessionParameter.totalTimeLimit) {
          time.limit = param.sessionParameter.totalTimeLimit; // セッションパラメータで制限時間が指定されたらその値を使用します
        }

        scene.loaded.add(function () {
          //3*10で計30枚のカードのデッキを作成
          var deck = new Deck_1.Deck();
          deck.init(scene); //シャッフルして配置

          deck.shuffle();
          deck.calclateCardsPosition();
          var font = new g.BitmapFont({
            src: scene.assets["bmpPng"],
            map: JSON.parse(scene.assets["glyph"].data),
            defaultGlyphWidth: 16,
            defaultGlyphHeight: 16
          });
          time.label = time.createLabel(font, scene);
          score.label = score.createLabel(font, scene);
          scene.append(time.label);
          scene.append(score.label);
          var board = new Board_1.Board(new g.E({
            scene: scene,
            y: Board_1.Board.posY
          })); //全てのカードバックをグループに入れ

          for (var _i = 0, _a = deck.cardList; _i < _a.length; _i++) {
            var card = _a[_i];
            board.group.append(card.surface);
            board.group.append(card.back);
          }

          var referee = new Referee_1.Referee();

          var _loop_1 = function _loop_1(card) {
            card.back.pointDown.add(function () {
              card.handleClick(scene, referee, deck.cardList, score, board, time);
            });
          }; //全てのカードにクリックハンドラ設定


          for (var _b = 0, _c = deck.cardList; _b < _c.length; _b++) {
            var card = _c[_b];

            _loop_1(card);
          }

          scene.append(board.group);

          var updateHandler = function updateHandler() {
            if (time.now <= 0) {
              for (var _i = 0, _a = deck.cardList; _i < _a.length; _i++) {
                var card = _a[_i];
                card.back.touchable = false;
                card.back.modified();
              }

              if (g.game.vars.gameState.allDone) {
                console.log("REST: " + g.game.vars.gameState.restTIme);
              }

              g.game.vars.gameState.score = score.calcFinalScore(); // RPGアツマール環境であればランキングを表示します

              if (param.isAtsumaru) {
                var boardId_1 = 1;
                window.RPGAtsumaru.experimental.scoreboards.setRecord(boardId_1, g.game.vars.gameState.score).then(function () {
                  window.RPGAtsumaru.experimental.scoreboards.display(boardId_1);
                });
              }

              scene.update.remove(updateHandler); // カウントダウンを止めるためにこのイベントハンドラを削除します
            }

            time.now -= 1 / g.game.fps;
            time.label.text = "TIME " + Math.ceil(time.now);
            time.label.invalidate();
            score.label.text = score.score + "Pt";
            score.label.invalidate();
          };

          scene.update.add(updateHandler); // ここまでゲーム内容を記述します
        });
        g.game.pushScene(scene);
      }

      exports.main = main;
    }, {
      "./Board": 1,
      "./Deck": 3,
      "./Referee": 4,
      "./Score": 5,
      "./Time": 6
    }],
    9: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      function createSprite(scene, assetID, x, y) {
        if (x === void 0) {
          x = 0;
        }

        if (y === void 0) {
          y = 0;
        }

        return new g.Sprite({
          touchable: true,
          scene: scene,
          src: scene.assets[assetID],
          x: x,
          y: y
        });
      }

      exports.createSprite = createSprite;
    }, {}]
  }, {}, [7])(7);
});